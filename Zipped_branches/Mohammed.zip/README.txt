This repo contains individual and challenge code for the BMEN 415 Project and University of Calgary W2023

This branch contains Mohammed's individual portions of the project for classification and regression. The Datasets used can be found on the 'main' branch.
