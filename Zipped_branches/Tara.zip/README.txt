This repo contains individual classification and regression model code for the BMEN 415 Project and University of Calgary W2023
