This branch contains Mateo's code for the BMEN 415 Project and University of Calgary W2023

Note: Each file (regression and classification) contains ALL 3 models. Can switch between the models by changing the version string variable in the model selection code block (ex. change to kNN for k-nearest neighbours, SVM for support vector machine, etc.)
